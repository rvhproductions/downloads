========= GuessGame for C# - Read this text =========

Thank you for downloading GuessGame for C#!

There are a few things that you need to know before playing GuessGame.


1. You may not distribute the game on unsafe websites.

2. You may not sell mods or sell parts of the game source code.

3. You may not copy source code and post it on websites.


GuessGame for C# is owned and developed by RVH Productions.
For our Terms of Service, please visit the RVH Productions website.