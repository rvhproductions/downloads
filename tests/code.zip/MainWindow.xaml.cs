﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace squared
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CompositionTarget.Rendering += loop;
        }

        public double playerPosX = 0;
        public double playerPosY = 0;
        public double movementY = 0;
        public double maxMovementY = 10;
        public double maxMovementYJump = 5;
        public double maxYPos = 300;
        public double jumpTimerMax = 100;
        public double jumpTimer = 0;
        public int count = 0;
        public bool isJumping = false;
        public bool isFalling = false;
        public Random rand = new Random();

        void loop(object sender, EventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.A))
            {
                playerPosX -= 2;
            }
            if (Keyboard.IsKeyDown(Key.D))
            {
                playerPosX += 2;
            }
            if (Keyboard.IsKeyDown(Key.Space))
            {
                if (!isJumping)
                {
                    movementY = maxMovementYJump;
                    isJumping = true;
                    isFalling = false;
                }
            }
            if (isFalling)
            {
                movementY += 0.25;
                playerPosY += movementY;
            }
            if (isJumping)
            {
                movementY -= 0.25;
                playerPosY -= movementY;
                if (movementY <= 0)
                {
                    isJumping = false;
                    isFalling = true;
                }
            }
            if (playerPosY >= maxYPos)
            {
                jumpTimer = 0;
                movementY = 0;
                isFalling = false;
            }
            update();
        }

        void update()
        {
            PlayerYPosText.Content = "Y: " + playerPosY;
            PlayerXPosText.Content = "X: " + playerPosX;
            Canvas.SetLeft(Player, playerPosX);
            Canvas.SetTop(Player, playerPosY);
            cam.ScrollToHorizontalOffset(playerPosX - this.Width / 2 + this.Player.Width / 2);
            cam.ScrollToVerticalOffset(playerPosY - this.Height / 2 + this.Player.Height / 2);
        }

        public void startup()
        {
            terrain.generateNewTerrain();
        }

        private void hide_tp_click(object sender, RoutedEventArgs e)
        {
            show_tp_button.Visibility = Visibility.Visible;
            tp.Visibility = Visibility.Hidden;
        }

        private void tp_click(object sender, RoutedEventArgs e)
        {
            try
            {
                double convxpos = Convert.ToDouble(setxpos.Text);
                double convypos = Convert.ToDouble(setypos.Text);
                Canvas.SetTop(Player, convypos);
                playerPosY = Canvas.GetTop(Player);
                PlayerYPosText.Content = "Y: " + playerPosY;
                Canvas.SetLeft(Player, convxpos);
                playerPosX = Canvas.GetLeft(Player);
                PlayerXPosText.Content = "X: " + playerPosX;
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Oops!");
            }
        }

        private void show_tp_click(object sender, RoutedEventArgs e)
        {
            show_tp_button.Visibility = Visibility.Hidden;
            tp.Visibility = Visibility.Visible;
        }

        private void region_click(object sender, RoutedEventArgs e)
        {
            generateRegionAroundPlayer();
        }

        void generateRegionAroundPlayer()
        {
            object[] blockArray = new object[15];
            for (int blocks = 0; blocks < 15; ++blocks)
            {
                long xCoord = (long)playerPosX + rand.Next(0, 200);
                long yCoord = (long)playerPosY + rand.Next(0, 200);
                Rectangle block = new Rectangle();
                int type = rand.Next(0, 3);
                if (type == 0)
                {
                    block.Name = "TALLGRASS";
                    block.Fill = Brushes.Green;
                    block.Width = 30;
                    block.Height = rand.Next(10, 30);
                }
                if (type == 1)
                {
                    block.Name = "STONE";
                    block.Fill = Brushes.Gray;
                    block.Width = rand.Next(10, 30);
                    block.Height = rand.Next(10, 30);
                }
                if (type == 2)
                {
                    block.Name = "TREASURE";
                    block.Fill = Brushes.Gold;
                    block.Width = rand.Next(10, 30);
                    block.Height = rand.Next(10, 30);
                }
                blockArray[blocks] = block;
                Canvas.SetLeft(block, xCoord);
                Canvas.SetTop(block, yCoord);
            }
            foreach (Rectangle block in blockArray)
            {
                blocks.Children.Add(block);
            }
        }
    }
}
