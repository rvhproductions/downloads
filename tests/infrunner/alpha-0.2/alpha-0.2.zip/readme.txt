InfRunner Alpha 0.2, build 22062023A

Red box
Enemy

Yellow box
3x score multiplier

Pink box
2x score multiplier

Green box
1x score multiplier

Keybinds:
ESC: Pause
Space: Jump
F3: Show/Hide variables and/or FPS
F5: Increase score by 1 million (dev feature, will be removed)
F6: Increase score multiplier by 100 (dev feature, will be removed)
F7: Spawn Enemy (dev feature, will be removed)

In the Settings menu, you can choose what graphics to render.
This could be useful for players on weaker computers.
Currently, the performance impact of the visual effects are unknown.

This is a preview!
Everything in the game will probably be changed multiple times.
This build has been made available so people can try it out if they want and give feedback.

RVH Productions is not responsible for anything this build may cause.
Play at your own risk (don't worry, its probably safe lol, just don't wanna be sued).

Don't agree to this? Do not play this game.

Because this game is still in very early alpha, please don't report bugs until the version reaches Alpha 1.0.