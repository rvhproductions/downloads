RVH Productions Game Preview
0.1 10052023A

Red box
Enemy

Yellow box
3x score multiplier

Pink box
2x score multiplier

Green box
1x score multiplier

Keybinds:
ESC: Pause
Space: Jump
F3: Show/Hide variables
F5: Increase score by 1 million (debug feature)